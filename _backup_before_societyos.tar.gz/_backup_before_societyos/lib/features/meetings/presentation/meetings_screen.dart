import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/premium_header.dart';

class MeetingsScreen extends StatefulWidget {
  const MeetingsScreen({super.key});

  @override
  State<MeetingsScreen> createState() => _MeetingsScreenState();
}

class _MeetingsScreenState extends State<MeetingsScreen> {
  final List<_Meeting> _meetings = [
    const _Meeting('Weekly Chapter Sync', 'Today • 06:00 PM', 'Google Meet'),
    const _Meeting('Event Operations Review', 'Friday • 05:30 PM', 'Seminar Hall 2'),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          const PremiumHeader(
            title: 'Meetings',
            subtitle: 'Keep every decision and discussion in sync',
            expandedHeight: 150,
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 120),
            sliver: SliverList.separated(
              itemCount: _meetings.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final meeting = _meetings[index];
                return Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: isDark ? AppColors.darkSurface : Colors.white,
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: isDark ? Colors.white10 : AppColors.lightGrey),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppColors.primaryGreen.withValues(alpha: .12),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Icon(Icons.videocam_rounded, color: AppColors.primaryGreen),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(meeting.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(fontWeight: FontWeight.w800, color: isDark ? Colors.white : AppColors.ink)),
                            const SizedBox(height: 4),
                            Text('${meeting.when} • ${meeting.place}', maxLines: 1, overflow: TextOverflow.ellipsis, style: GoogleFonts.inter(fontSize: 12, color: AppColors.mediumGrey)),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: 'Copy meeting details',
                        onPressed: () async {
                          await Clipboard.setData(ClipboardData(text: '${meeting.title}\n${meeting.when}\n${meeting.place}'));
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${meeting.title} details copied.')));
                          }
                        },
                        icon: const Icon(Icons.content_copy_rounded, size: 19, color: AppColors.primaryGreen),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createMeeting,
        backgroundColor: AppColors.primaryGreen,
        icon: const Icon(Icons.add_rounded, color: Colors.white),
        label: Text('NEW MEETING', style: GoogleFonts.inter(color: Colors.white, fontWeight: FontWeight.w800, letterSpacing: 1)),
      ),
    );
  }

  Future<void> _createMeeting() async {
    final controller = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Schedule meeting'),
        content: TextField(controller: controller, autofocus: true, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Meeting title')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('Add')),
        ],
      ),
    );
    controller.dispose();
    if (title == null || title.isEmpty || !mounted) return;
    setState(() => _meetings.insert(0, _Meeting(title, 'To be scheduled', 'Venue pending')));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$title added to your meeting board.')));
  }
}

class _Meeting {
  const _Meeting(this.title, this.when, this.place);
  final String title;
  final String when;
  final String place;
}
